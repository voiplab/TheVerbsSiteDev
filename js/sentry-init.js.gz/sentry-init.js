if (Sentry && location.hostname !== 'localhost') {
  Sentry.init({dsn: 'https://cebde1b6ba654e358ce216bf4f1da035@o387727.ingest.sentry.io/5223445'});
}
