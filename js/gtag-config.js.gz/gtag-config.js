window.dataLayer = window.dataLayer || [];

dataLayer.push('js', new Date());
dataLayer.push('config', 'theverbs-cd87a');