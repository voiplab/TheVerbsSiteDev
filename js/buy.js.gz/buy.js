function buyItem(item) {
  AndroidFunction.buyItem(item);
}